<div class="container"><!-- container -->
        
        	<div class="row"><!-- row -->
            
                <div id="k-top-search" class="col-lg-12 clearfix" style="display:none;"><!-- top search -->
                
                    <form action="#" id="top-searchform" method="get" role="search">
                        <div class="input-group">
                            <input type="text" name="s" id="sitesearch" class="form-control" autocomplete="off" placeholder="Type in keyword(s) then hit Enter on keyboard" />
                        </div>
                    </form>
                    
                    <div id="bt-toggle-search" class="search-icon text-center"><i class="s-open fa fa-search"></i><i class="s-close fa fa-times"></i></div><!-- toggle search button -->
                
                </div><!-- top search end -->
            
            	<div class="k-breadcrumbs col-lg-12 clearfix"><!-- breadcrumbs -->
                
                	<ol class="breadcrumb" >
                    	<li><a href="#">Home</a></li>
                        <li class="active">About Us</li>
                    </ol>
                    
                </div><!-- breadcrumbs end -->               
                
            </div><!-- row end -->
            
            <div class="row no-gutter"><!-- row -->
                
                <div class="col-lg-8 col-md-8"><!-- doc body wrapper -->
                	
                    <div class="col-padded"><!-- inner custom column -->
                    
                    	<div class="row gutter"><!-- row -->
                        
                        	<div class="col-lg-12 col-md-12">
                    
                                
                                
                                <h1 class="page-title">CEO Message</h1>
                                
                                <div class="news-body">
                                
                                    <p>
									Ever since the big bang and the consolidation of universe, the knowledge is expanding in all directions,
									The expansion of knowledge stems from a) Allah Al-Mighty, the sole creator of all and b) the quest of human beings. 
									The creator "Allah" is hte fountain of knowledge who had been dropping tips through his chosen prophets to the mankind
									according to latter's level of assimilation. The people had been exploring, evaluating and inventing articles of use through
									permutation and combination. The demarche of knowledge rolled over the old thoughts and trumpeted the new ideas, theories and usage.
									But is has a common discourse of disregarding the obsolete or less efficient to be replaced with new or more efficient and
									productive articles. The development and expansion of knowledge has changed the face of earth - the environment and the inhabitants. 
									The expansion of knowledge has induced phenomenal growth in the physical, material and other natural resources, making the supplies 
									abundant for 6 billion today, while there were shortages, diseases and famine all around when the population was much less in 15 or 16 century.
									</p>
									<p>
									The base of all stem from productivity and the inventions were made by such jewels like Edison, Einstein and Bill Gates who were back 
									benchers at their formative stages but once they were discovered they out shined every body.
									</p>
									<p>
									We should look forward for such jewels from our society to contribute their due for the prosperity fo society.
									</p>
									
                                </div>
                            
                            </div>
                        
                        </div><!-- row end -->
                        
                        <div class="row gutter k-equal-height"><!-- row -->
                        
                            
                        </div><!-- row end -->           
                    
                    </div><!-- inner custom column end -->
                    
                </div><!-- doc body wrapper end -->
                
                <div id="k-sidebar" class="col-lg-4 col-md-4"><!-- sidebar wrapper -->
                	
                     <?php $this->renderPartial('_sidebar', array('tests' => $tests)); ?>
                     <!-- inner custom column end -->
                    
                </div><!-- sidebar wrapper end -->
            
            </div><!-- row end -->
        
        </div><!-- container end -->