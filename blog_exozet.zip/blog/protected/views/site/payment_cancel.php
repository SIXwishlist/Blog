
    <section id="main-slider" class="no-margin">
        <div class="carousel slide">
           
            <div class="carousel-inner">

                <div class="item active carousel3" >
                    <div class="container">
                        
                        <div class="row slide-margin">
                            <div class="col-sm-6">
                                <div class="carousel-content">
                                <h1 class="top animation animated-item-1" style="color: #000;">
                                   Payment Cancel           
                                 </h1>
                                </div>
                             </div>

                            

                        </div>
                    </div>
                </div><!--/.item-->
            </div><!--/.carousel-inner-->
        </div><!--/.carousel-->
        
    </section><!--/#main-slider-->

    <section id="feature" >
        <div class="container">
           <div class="left wow fadeInDown">
                <h4>You have canceled payment for account subscription.</h4><br/>
                <h5></h5>
                <h3>Please send us your feedback with reason to cancel payment process.</h3>
                <div class="feature-wrap" style="padding:45px;">
                <div class="text-center">
                	<button class="slider" onclick="location.href='<?php echo Yii::app()->createurl('contact');?>'"> Send your feedback</button>
                </div>
                </div>
                <p class="lead"></p>
            </div>

                </div><!--/.services-->
            </div><!--/.row-->    
        </div><!--/.container-->
    </section><!--/#feature-->
